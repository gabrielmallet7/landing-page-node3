"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { 
  Search, 
  Pen, 
  Code, 
  Layers, 
  Terminal, 
  Mail, 
  Instagram, 
  ChevronDown, 
  ChevronLeft, 
  ChevronRight,
  Menu,
  X,
  Monitor,
  User,
  Linkedin,
  Maximize2
} from "lucide-react"

// =============================================
// CAROUSEL SLIDE DATA
// Replace src with actual image paths when available
// =============================================

const gymNodeSlides = [
  { src: "", label: "Panel general", description: "Vista central de operación diaria del gimnasio" },
  { src: "", label: "Clientes", description: "Gestión completa del padrón de socios activos" },
  { src: "", label: "Cuotas", description: "Control de pagos, vencimientos y estados de cuenta" },
  { src: "", label: "Caja y tesorería", description: "Seguimiento de ingresos y movimientos de caja" },
  { src: "", label: "Movimientos", description: "Historial detallado de operaciones registradas" },
  { src: "", label: "Administración", description: "Configuración general y parámetros del sistema" },
]

const trackitSlides = [
  { src: "", label: "Tareas", description: "Organización y seguimiento de entregas pendientes" },
  { src: "", label: "Calendario", description: "Vista mensual y semanal de actividades académicas" },
  { src: "", label: "Inicio", description: "Panel central con resumen del estado académico" },
  { src: "", label: "Concentración", description: "Modo foco para sesiones de estudio sin distracciones" },
  { src: "", label: "Estadísticas", description: "Métricas de productividad y avance académico" },
  { src: "", label: "Materias", description: "Gestión de asignaturas, horarios y contenidos" },
]

// =============================================
// INTERSECTION OBSERVER HOOK
// =============================================

function useInView(options?: IntersectionObserverInit) {
  const ref = useRef<HTMLDivElement>(null)
  const [isInView, setIsInView] = useState(false)

  useEffect(() => {
    const element = ref.current
    if (!element) return

    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsInView(true)
        observer.unobserve(element)
      }
    }, { threshold: 0.1, ...options })

    observer.observe(element)
    return () => observer.disconnect()
  }, [options])

  return { ref, isInView }
}

// =============================================
// PROJECT CAROUSEL COMPONENT (NEW DESIGN)
// =============================================

type SlideData = {
  src: string
  label: string
  description: string
}

function ProjectCarousel({ slides }: { slides: SlideData[] }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isFullscreen, setIsFullscreen] = useState(false)

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1)
    }
  }

  const goToNext = () => {
    if (currentIndex < slides.length - 1) {
      setCurrentIndex((prev) => prev + 1)
    }
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  // Handle ESC key to exit fullscreen
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFullscreen) {
        setIsFullscreen(false)
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isFullscreen])

  // Prevent body scroll when fullscreen
  useEffect(() => {
    if (isFullscreen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }
    return () => {
      document.body.style.overflow = ""
    }
  }, [isFullscreen])

  const currentSlide = slides[currentIndex]

  // Regular carousel with lateral previews
  const RegularCarousel = () => (
    <div className="relative w-full" style={{ overflow: "visible" }}>
      {/* Inner wrapper with overflow hidden and padding for previews */}
      <div 
        className="relative overflow-hidden h-[280px] sm:h-[50vw] lg:h-[70vh] min-h-[280px] max-h-[800px]"
        style={{ padding: "0 40px", paddingLeft: "40px", paddingRight: "40px" }}
      >
        {/* Slides track */}
        <div 
          className="relative h-full flex transition-transform duration-400 ease-in-out"
          style={{ 
            transform: `translateX(calc(-${currentIndex * 100}% - ${currentIndex * 16}px))`,
            gap: "16px"
          }}
        >
          {slides.map((slide, index) => {
            const isActive = index === currentIndex
            const isPrev = index === currentIndex - 1
            const isNext = index === currentIndex + 1
            const isVisible = isActive || isPrev || isNext

            return (
              <div
                key={index}
                className="relative flex-shrink-0 transition-all duration-400 ease-in-out"
                style={{
                  width: "100%",
                  transform: isActive ? "scale(1)" : "scale(0.92)",
                  opacity: isActive ? 1 : isVisible ? 0.45 : 0,
                }}
              >
                <div className="relative w-full h-full rounded-[16px] overflow-hidden">
                  {/* Image or Placeholder */}
                  {slide.src ? (
                    <Image
                      src={slide.src}
                      alt={slide.label}
                      fill
                      className="object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-[#1E293B] flex items-center justify-center">
                      <Monitor className="w-10 h-10 text-[#94A3B8]" strokeWidth={1.5} />
                    </div>
                  )}

                  {/* Gradient Overlay - only on active slide */}
                  {isActive && (
                    <div
                      className="absolute bottom-0 left-0 right-0 pointer-events-none"
                      style={{
                        height: "45%",
                        background: "linear-gradient(to top, rgba(10, 15, 30, 0.95) 0%, rgba(10, 15, 30, 0) 100%)",
                      }}
                    />
                  )}

                  {/* Text inside gradient - only on active slide */}
                  {isActive && (
                    <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-8 lg:px-10 lg:py-8">
                      <span className="font-mono text-xs text-[#94A3B8] block mb-1">
                        {slide.label}
                      </span>
                      <p className="text-[15px] text-[#F0F4F8]">
                        {slide.description}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {/* Navigation Arrows */}
        <button
          onClick={goToPrevious}
          className={`absolute left-[56px] top-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center rounded-full bg-[rgba(10,15,30,0.6)] border border-[rgba(255,255,255,0.1)] text-[#F0F4F8] hover:bg-[rgba(0,194,203,0.2)] hover:border-[rgba(0,194,203,0.4)] transition-all duration-200 z-20 ${
            currentIndex === 0 ? "opacity-30 cursor-not-allowed" : ""
          }`}
          aria-label="Anterior"
          disabled={currentIndex === 0}
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={goToNext}
          className={`absolute right-[56px] top-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center rounded-full bg-[rgba(10,15,30,0.6)] border border-[rgba(255,255,255,0.1)] text-[#F0F4F8] hover:bg-[rgba(0,194,203,0.2)] hover:border-[rgba(0,194,203,0.4)] transition-all duration-200 z-20 ${
            currentIndex === slides.length - 1 ? "opacity-30 cursor-not-allowed" : ""
          }`}
          aria-label="Siguiente"
          disabled={currentIndex === slides.length - 1}
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Fullscreen Button */}
        <button
          onClick={toggleFullscreen}
          className="absolute top-4 right-[56px] w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center rounded-full bg-[rgba(10,15,30,0.6)] border border-[rgba(255,255,255,0.1)] text-[#F0F4F8] hover:bg-[rgba(0,194,203,0.2)] hover:border-[rgba(0,194,203,0.4)] transition-all duration-200 z-20"
          aria-label="Pantalla completa"
        >
          <Maximize2 className="w-[18px] h-[18px]" />
        </button>
      </div>

      {/* Dots Indicator */}
      <div className="flex justify-center gap-1.5 mt-4">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-2 rounded transition-all duration-200 ${
              index === currentIndex
                ? "bg-[#00C2CB] w-5"
                : "bg-[#1E293B] w-2 hover:bg-[#2D3B4E]"
            }`}
            aria-label={`Ir a imagen ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )

  // Fullscreen carousel - no lateral previews
  const FullscreenCarousel = () => (
    <div 
      className="fixed z-[9999] bg-[#0A0F1E]"
      style={{ 
        top: 0, 
        right: 0, 
        bottom: 0, 
        left: 0,
        width: "100vw",
        height: "100vh"
      }}
    >
      {/* Full viewport slide */}
      <div className="relative w-full h-full">
        {slides.map((slide, index) => (
          <div
            key={index}
            className="absolute inset-0 transition-transform duration-400 ease-in-out"
            style={{
              transform: `translateX(${(index - currentIndex) * 100}%)`,
            }}
          >
            {/* Image or Placeholder */}
            {slide.src ? (
              <Image
                src={slide.src}
                alt={slide.label}
                fill
                className="object-cover"
              />
            ) : (
              <div className="w-full h-full bg-[#1E293B] flex items-center justify-center">
                <Monitor className="w-16 h-16 text-[#94A3B8]" strokeWidth={1.5} />
              </div>
            )}
          </div>
        ))}

        {/* Gradient Overlay */}
        <div
          className="absolute bottom-0 left-0 right-0 pointer-events-none"
          style={{
            height: "35%",
            background: "linear-gradient(to top, rgba(10, 15, 30, 0.95) 0%, rgba(10, 15, 30, 0) 100%)",
          }}
        />

        {/* Text inside gradient */}
        <div className="absolute bottom-16 left-0 right-0 px-8 sm:px-12">
          <span className="font-mono text-sm text-[#94A3B8] block mb-2">
            {currentSlide.label}
          </span>
          <p className="text-lg text-[#F0F4F8] max-w-2xl">
            {currentSlide.description}
          </p>
        </div>

        {/* Navigation Arrows */}
        <button
          onClick={goToPrevious}
          className={`absolute left-6 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center rounded-full bg-[rgba(10,15,30,0.6)] border border-[rgba(255,255,255,0.1)] text-[#F0F4F8] hover:bg-[rgba(0,194,203,0.2)] hover:border-[rgba(0,194,203,0.4)] transition-all duration-200 z-20 ${
            currentIndex === 0 ? "opacity-30 cursor-not-allowed" : ""
          }`}
          aria-label="Anterior"
          disabled={currentIndex === 0}
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button
          onClick={goToNext}
          className={`absolute right-6 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center rounded-full bg-[rgba(10,15,30,0.6)] border border-[rgba(255,255,255,0.1)] text-[#F0F4F8] hover:bg-[rgba(0,194,203,0.2)] hover:border-[rgba(0,194,203,0.4)] transition-all duration-200 z-20 ${
            currentIndex === slides.length - 1 ? "opacity-30 cursor-not-allowed" : ""
          }`}
          aria-label="Siguiente"
          disabled={currentIndex === slides.length - 1}
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        {/* Close Button */}
        <button
          onClick={toggleFullscreen}
          className="absolute z-20 w-10 h-10 flex items-center justify-center rounded-full bg-[rgba(10,15,30,0.6)] border border-[rgba(255,255,255,0.1)] text-[#F0F4F8] hover:bg-[rgba(0,194,203,0.2)] hover:border-[rgba(0,194,203,0.4)] transition-all duration-200"
          style={{ top: "20px", right: "20px" }}
          aria-label="Cerrar pantalla completa"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Fullscreen Dots */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-1.5 z-20">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`h-2 rounded transition-all duration-200 ${
                index === currentIndex
                  ? "bg-[#00C2CB] w-5"
                  : "bg-[#1E293B] w-2 hover:bg-[#2D3B4E]"
              }`}
              aria-label={`Ir a imagen ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  )

  return (
    <>
      <RegularCarousel />
      {isFullscreen && <FullscreenCarousel />}
    </>
  )
}

// =============================================
// ANIMATED COMPONENTS
// =============================================

type AnimationDirection = "up" | "down" | "left" | "right" | "fade"

function AnimatedSection({ 
  children, 
  className = "",
  direction = "up",
  delay = 0
}: { 
  children: React.ReactNode
  className?: string
  direction?: AnimationDirection
  delay?: number
}) {
  const { ref, isInView } = useInView()

  const getTransform = () => {
    if (!isInView) {
      switch (direction) {
        case "up": return "translateY(32px)"
        case "down": return "translateY(-16px)"
        case "left": return "translateX(-32px)"
        case "right": return "translateX(32px)"
        case "fade": return "translateY(0)"
        default: return "translateY(32px)"
      }
    }
    return "translate(0)"
  }

  return (
    <div
      ref={ref}
      style={{
        opacity: isInView ? 1 : 0,
        transform: getTransform(),
        transition: `all 600ms ease-out ${delay}ms`
      }}
      className={className}
    >
      {children}
    </div>
  )
}

function StaggeredBadges({ 
  items 
}: { 
  items: string[]
}) {
  const { ref, isInView } = useInView()

  return (
    <div ref={ref} className="flex flex-wrap justify-center gap-4 sm:gap-5">
      {items.map((tech, index) => (
        <div
          key={tech}
          className="px-6 py-3 rounded-lg bg-[#161D2E] border border-[#1E293B] text-muted-foreground font-medium text-[15px] hover:text-[#F0F4F8] hover:border-[rgba(0,194,203,0.4)] hover:shadow-[0_0_12px_rgba(0,194,203,0.15)] transition-all duration-200 cursor-default"
          style={{
            opacity: isInView ? 1 : 0,
            transition: `opacity 600ms ease-out ${index * 60}ms`
          }}
        >
          {tech}
        </div>
      ))}
    </div>
  )
}

// =============================================
// NAVBAR COMPONENT
// =============================================

function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navLinks = [
    { href: "#nosotros", label: "Nosotros" },
    { href: "#equipo", label: "Equipo" },
    { href: "#proyectos", label: "Proyectos" },
    { href: "#servicios", label: "Servicios" },
    { href: "#contacto", label: "Contacto" },
  ]

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? "bg-[#0A0F1E]/85 backdrop-blur-[12px] border-b border-[#1E293B]/80" 
          : "bg-transparent"
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <a href="#" className="text-foreground font-bold text-xl tracking-tight">
            NODE3
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="relative text-muted-foreground hover:text-foreground font-medium text-sm transition-colors duration-200 group"
              >
                {link.label}
                <span className="absolute left-0 -bottom-1 w-0 h-[2px] bg-[#00C2CB] transition-all duration-250 group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-[#1E293B]/50">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="relative inline-block text-muted-foreground hover:text-foreground font-medium text-sm transition-colors duration-200 group"
                >
                  {link.label}
                  <span className="absolute left-0 -bottom-0.5 w-0 h-[2px] bg-[#00C2CB] transition-all duration-250 group-hover:w-full" />
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

// =============================================
// HERO SECTION
// =============================================

function HeroSection() {
  const { ref, isInView } = useInView()

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 overflow-hidden bg-[#0A0F1E]">
      {/* Subtle Grid Background */}
      <div 
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `radial-gradient(#00C2CB 1px, transparent 1px)`,
          backgroundSize: "24px 24px"
        }}
      />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Badge */}
        <div 
          className="inline-flex items-center px-3 py-1.5 mb-6 sm:mb-8 rounded-[6px] bg-[#161D2E] border border-[#1E293B]"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? "translateY(0)" : "translateY(-16px)",
            transition: "all 600ms ease-out 0ms"
          }}
        >
          <span className="font-mono text-xs sm:text-sm text-muted-foreground">
            {"// ingeniería · diseño · implementación"}
          </span>
        </div>

        {/* Main Title */}
        <h1 
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-foreground leading-tight mb-6 text-balance"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? "translateY(0)" : "translateY(24px)",
            transition: "all 600ms ease-out 150ms"
          }}
        >
          Construimos software con{" "}
          <span className="text-[#00C2CB]">criterio de ingeniería</span>
        </h1>

        {/* Subtitle */}
        <p 
          className="max-w-xl mx-auto text-base sm:text-lg text-muted-foreground mb-8 sm:mb-10 leading-relaxed text-pretty"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? "translateY(0)" : "translateY(24px)",
            transition: "all 600ms ease-out 300ms"
          }}
        >
          Transformamos ideas en productos digitales sólidos, claros y bien ejecutados. 
          Desde el análisis hasta la implementación, trabajamos con proceso, comunicación 
          directa y foco en calidad.
        </p>

        {/* CTA Buttons */}
        <div 
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? "translateY(0)" : "translateY(24px)",
            transition: "all 600ms ease-out 450ms"
          }}
        >
          <a
            href="#proyectos"
            className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 rounded-lg bg-[#00C2CB] text-[#0A0F1E] font-semibold text-sm transition-all duration-200 hover:shadow-[0_0_20px_rgba(0,194,203,0.25)]"
          >
            Ver proyectos
          </a>
          <a
            href="#contacto"
            className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 rounded-lg border border-[#00C2CB] text-[#00C2CB] font-semibold text-sm transition-all duration-200 hover:shadow-[0_0_20px_rgba(0,194,203,0.25)]"
          >
            Hablemos
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  )
}

// =============================================
// ABOUT SECTION
// =============================================

function AboutSection() {
  const pillars = [
    {
      icon: Search,
      title: "Análisis",
      description: "Entendemos el problema, el contexto y los objetivos antes de escribir una sola línea de código."
    },
    {
      icon: Pen,
      title: "Diseño",
      description: "Definimos una solución clara, usable y escalable, pensada para funcionar bien desde el inicio."
    },
    {
      icon: Code,
      title: "Implementación",
      description: "Construimos con foco en calidad técnica, mantenibilidad y una ejecución prolija de punta a punta."
    }
  ]

  return (
    <section id="nosotros" className="min-h-screen py-20 sm:py-[120px] px-4 sm:px-6 lg:px-8 bg-[#111827] scroll-mt-20 flex flex-col justify-center">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left Column - Text */}
          <AnimatedSection direction="left">
            <span className="font-mono text-sm text-muted-foreground mb-4 block">
              {"// sobre nosotros"}
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6 text-balance">
              Tres ingenieros. Un proceso claro.
            </h2>
            <p className="text-base sm:text-[17px] text-muted-foreground leading-relaxed">
              NODE3 es un estudio de ingeniería de software formado por tres estudiantes 
              avanzados de ingeniería. Nos especializamos en el desarrollo de productos SaaS 
              y soluciones digitales bien construidas, con una forma de trabajo clara, 
              técnica y ordenada.
            </p>
          </AnimatedSection>

          {/* Right Column - Cards */}
          <div className="flex flex-col gap-4">
            {pillars.map((pillar, index) => (
              <AnimatedSection key={index} direction="right" delay={index * 100}>
                <div className="p-5 sm:p-6 rounded-xl bg-[#161D2E] border border-[#1E293B] hover:border-[#00C2CB]/30 hover:-translate-y-1 transition-all duration-250 ease-out group">
                  <pillar.icon className="w-5 h-5 sm:w-6 sm:h-6 text-[#00C2CB] mb-3" strokeWidth={1.5} />
                  <h3 className="text-base sm:text-lg font-semibold text-foreground mb-2">
                    {pillar.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {pillar.description}
                  </p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

// =============================================
// TEAM SECTION
// =============================================

function TeamSection() {
  const teamMembers = [
    { name: "Integrante 1", role: "Ingeniería de Software" },
    { name: "Integrante 2", role: "Ingeniería de Software" },
    { name: "Integrante 3", role: "Ingeniería de Software" },
  ]

  return (
    <section id="equipo" className="py-20 sm:py-[120px] px-4 sm:px-6 lg:px-8 bg-[#0A0F1E] scroll-mt-20">
      <div className="max-w-6xl mx-auto">
        <AnimatedSection>
          <div className="text-center mb-12 sm:mb-16">
            <span className="font-mono text-sm text-muted-foreground mb-4 block">
              {"// equipo"}
            </span>
            <h2 className="text-3xl sm:text-[40px] font-bold text-foreground mb-4 text-balance">
              Las personas detrás del código
            </h2>
            <p className="text-muted-foreground text-[17px]">
              Tres estudiantes avanzados de ingeniería con foco en construir software real.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-6">
          {teamMembers.map((member, index) => (
            <AnimatedSection key={index} direction="up" delay={index * 100}>
              <div className="p-6 rounded-xl bg-[#161D2E] border border-[#1E293B] hover:border-[rgba(0,194,203,0.3)] hover:shadow-[0_0_20px_rgba(0,194,203,0.08)] hover:-translate-y-1 transition-all duration-200">
                {/* Avatar */}
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-[#1E293B] flex items-center justify-center">
                  <User className="w-8 h-8 text-[#94A3B8]" strokeWidth={1.5} />
                </div>

                {/* Name */}
                <h3 className="text-lg font-semibold text-foreground text-center mb-1">
                  {member.name}
                </h3>

                {/* Role */}
                <p className="font-mono text-sm text-muted-foreground text-center mb-4">
                  {member.role}
                </p>

                {/* Divider */}
                <div className="border-t border-[#1E293B] mb-4" />

                {/* LinkedIn Icon */}
                <div className="flex justify-center">
                  <button className="text-[#94A3B8] hover:text-foreground transition-colors duration-200 cursor-pointer">
                    <Linkedin className="w-5 h-5" strokeWidth={1.5} />
                  </button>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

// =============================================
// PROJECTS SECTION
// =============================================

function ProjectBlock({
  name,
  description,
  stack,
  slides,
  delay = 0
}: {
  name: string
  description: string
  stack: string[]
  slides: SlideData[]
  delay?: number
}) {
  return (
    <AnimatedSection direction="up" delay={delay}>
      <div className="w-full">
        {/* Project Header */}
        <div className="flex flex-wrap items-center gap-4 mb-6 px-0 sm:px-[2.5%] lg:px-[5%]">
          {/* Logo Placeholder */}
          <div className="w-[120px] h-[36px] rounded-[8px] border border-dashed border-[#1E293B] flex items-center justify-center">
            <span className="font-mono text-[11px] text-[#94A3B8]">logo próximamente</span>
          </div>

          {/* Project Name */}
          <h3 className="text-[24px] font-bold text-[#F0F4F8]">
            {name}
          </h3>

          {/* Status Badge */}
          <div className="inline-flex items-center px-2.5 py-1 rounded-[6px] bg-[#161D2E] border border-[#1E293B]">
            <span className="font-mono text-xs text-[#94A3B8]">
              MVP en desarrollo
            </span>
          </div>
        </div>

        {/* Carousel */}
        <ProjectCarousel slides={slides} />

        {/* Project Info */}
        <div className="mt-8 px-0 sm:px-[2.5%] lg:px-[5%]">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
            {/* Description - Left */}
            <p className="text-[15px] text-[#94A3B8] leading-relaxed max-w-[480px]">
              {description}
            </p>

            {/* Stack & CTA - Right */}
            <div className="flex flex-col items-start lg:items-end gap-4">
              {/* Stack Tags */}
              <div className="flex flex-wrap gap-2 lg:justify-end">
                {stack.map((tech) => (
                  <span
                    key={tech}
                    className="font-mono text-xs px-2.5 py-1 rounded-[6px] bg-[#0A0F1E] border border-[#1E293B] text-[#94A3B8] hover:border-[rgba(0,194,203,0.3)] hover:text-[#F0F4F8] transition-all duration-150"
                  >
                    {tech}
                  </span>
                ))}
              </div>

              {/* CTA */}
              <button className="inline-flex items-center justify-center px-5 py-2.5 rounded-lg border border-[#00C2CB] text-[#00C2CB] font-semibold text-sm transition-all duration-200 hover:shadow-[0_0_20px_rgba(0,194,203,0.25)]">
                Ver más
              </button>
            </div>
          </div>
        </div>
      </div>
    </AnimatedSection>
  )
}

function ProjectsSection() {
  return (
    <section id="proyectos" className="pt-24 sm:pt-[120px] pb-20 sm:pb-[120px] scroll-mt-20 bg-[#0A0F1E]">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <AnimatedSection direction="up">
            <div className="text-center mb-16 sm:mb-20">
              <span className="font-mono text-sm text-muted-foreground mb-4 block">
                {"// proyectos"}
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4 text-balance">
                Lo que estamos construyendo
              </h2>
              <p className="text-muted-foreground">
                Dos productos SaaS propios, en desarrollo activo.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </div>

      {/* Project 1 - Gym Node */}
      <div className="mb-20 sm:mb-[80px]">
        <ProjectBlock
          name="Gym Node"
          description="Sistema de gestión para gimnasios diseñado para centralizar la operación diaria en una sola plataforma. Permite administrar clientes, asistencias, cuotas, precios e información administrativa con una estructura clara, moderna y preparada para crecer."
          stack={["Java", "Spring Boot", "PostgreSQL", "React", "Docker", "JWT"]}
          slides={gymNodeSlides}
          delay={100}
        />
      </div>

      {/* Project 2 - TrackIt-One */}
      <div>
        <ProjectBlock
          name="TrackIt-One"
          description="Aplicación de organización académica pensada para estudiantes que quieren administrar mejor su tiempo. Integra tareas, materias, calendario, seguimiento de entregas, estadísticas y espacios de concentración en una sola experiencia."
          stack={["React", "Next.js", "PostgreSQL", "Go"]}
          slides={trackitSlides}
          delay={200}
        />
      </div>
    </section>
  )
}

// =============================================
// SERVICES SECTION
// =============================================

function ServicesSection() {
  return (
    <section id="servicios" className="min-h-screen py-20 sm:py-[120px] px-4 sm:px-6 lg:px-8 bg-[#111827] scroll-mt-20 flex flex-col justify-center">
      <div className="max-w-6xl mx-auto">
        <AnimatedSection direction="up">
          <div className="text-center mb-12 sm:mb-16">
            <span className="font-mono text-sm text-muted-foreground mb-4 block">
              {"// servicios"}
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground text-balance">
              ¿En qué podemos ayudarte?
            </h2>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Primary Service - SaaS */}
          <AnimatedSection direction="up" delay={100}>
            <div className="relative h-full p-6 sm:p-8 rounded-xl bg-[#161D2E] border border-[#00C2CB]/30 hover:border-[#00C2CB]/50 hover:-translate-y-1 transition-all duration-250 ease-out">
              {/* Badge */}
              <div className="absolute top-4 right-4 px-2 py-0.5 rounded-[6px] bg-[#00C2CB]/10 border border-[#00C2CB]/30">
                <span className="text-[10px] sm:text-xs font-medium text-[#00C2CB]">especialidad</span>
              </div>

              <Layers className="w-6 h-6 sm:w-7 sm:h-7 text-[#00C2CB] mb-4" strokeWidth={1.5} />
              <h3 className="text-xl sm:text-2xl font-bold text-foreground mb-3">
                Desarrollo de productos SaaS
              </h3>
              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                Diseñamos y desarrollamos productos SaaS con visión de largo plazo. 
                Trabajamos desde la definición de la solución hasta su implementación, 
                cuidando la arquitectura, la experiencia de uso y la calidad técnica.
              </p>
            </div>
          </AnimatedSection>

          {/* Secondary Service - Custom */}
          <AnimatedSection direction="up" delay={200}>
            <div className="h-full p-6 sm:p-8 rounded-xl bg-[#161D2E] border border-[#1E293B] hover:border-[#00C2CB]/30 hover:-translate-y-1 transition-all duration-250 ease-out">
              <Terminal className="w-6 h-6 sm:w-7 sm:h-7 text-[#00C2CB] mb-4" strokeWidth={1.5} />
              <h3 className="text-xl sm:text-2xl font-bold text-foreground mb-3">
                Desarrollo a medida
              </h3>
              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                Creamos soluciones específicas para necesidades concretas, con una 
                ejecución clara, prolija y alineada con los objetivos del proyecto.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}

// =============================================
// TECHNOLOGIES SECTION
// =============================================

function TechnologiesSection() {
  const technologies = ["React", "Next.js", "Go", "Java", "Spring Boot", "PostgreSQL", "Docker"]

  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#111827]">
      <div className="max-w-6xl mx-auto">
        <AnimatedSection direction="up">
          <div className="text-center mb-10 sm:mb-12">
            <span className="font-mono text-sm text-muted-foreground mb-4 block">
              {"// stack tecnológico"}
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground text-balance">
              Las herramientas con las que construimos
            </h2>
          </div>
        </AnimatedSection>

        <StaggeredBadges items={technologies} />
      </div>
    </section>
  )
}

// =============================================
// CONTACT SECTION
// =============================================

function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log("Form submitted:", formData)
  }

  return (
    <section id="contacto" className="min-h-screen py-20 sm:py-[120px] px-4 sm:px-6 lg:px-8 scroll-mt-20 flex flex-col justify-center bg-[#0A0F1E]">
      <div className="max-w-xl mx-auto">
        <AnimatedSection direction="down">
          <div className="text-center mb-10 sm:mb-12">
            <span className="font-mono text-sm text-muted-foreground mb-4 block">
              {"// contacto"}
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4 text-balance">
              ¿Tenés un proyecto en mente?
            </h2>
            <p className="text-muted-foreground text-pretty">
              Si estás buscando un equipo técnico claro, serio y comprometido 
              con construir bien, conversemos.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection direction="up" delay={200}>
          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
            <div>
              <input
                type="text"
                placeholder="Tu nombre"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 rounded-lg bg-[#161D2E] border border-[#1E293B] text-foreground placeholder:text-muted-foreground focus:border-[#00C2CB] focus:outline-none transition-colors duration-200"
                required
              />
            </div>
            <div>
              <input
                type="email"
                placeholder="Tu email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 rounded-lg bg-[#161D2E] border border-[#1E293B] text-foreground placeholder:text-muted-foreground focus:border-[#00C2CB] focus:outline-none transition-colors duration-200"
                required
              />
            </div>
            <div>
              <textarea
                placeholder="Contanos de qué se trata tu proyecto"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={4}
                className="w-full px-4 py-3 rounded-lg bg-[#161D2E] border border-[#1E293B] text-foreground placeholder:text-muted-foreground focus:border-[#00C2CB] focus:outline-none transition-colors duration-200 resize-none"
                required
              />
            </div>
            <div className="flex justify-center">
              <button
                type="submit"
                className="w-full max-w-[260px] py-3 rounded-lg bg-[#00C2CB] text-[#0A0F1E] font-semibold text-sm transition-all duration-200 hover:shadow-[0_0_20px_rgba(0,194,203,0.25)]"
              >
                Enviar mensaje
              </button>
            </div>
          </form>

          {/* Contact Info */}
          <div className="mt-10 pt-8 border-t border-[#1E293B]">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8">
              <a
                href="mailto:node3sw@gmail.com"
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors duration-200"
              >
                <Mail className="w-4 h-4" strokeWidth={1.5} />
                <span className="text-sm">node3sw@gmail.com</span>
              </a>
              <a
                href="https://instagram.com/node3sw"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors duration-200"
              >
                <Instagram className="w-4 h-4" strokeWidth={1.5} />
                <span className="text-sm">@node3sw</span>
              </a>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}

// =============================================
// FOOTER SECTION
// =============================================

function Footer() {
  const navLinks = [
    { href: "#nosotros", label: "Nosotros" },
    { href: "#equipo", label: "Equipo" },
    { href: "#proyectos", label: "Proyectos" },
    { href: "#servicios", label: "Servicios" },
    { href: "#contacto", label: "Contacto" },
  ]

  return (
    <footer className="py-8 sm:py-12 px-4 sm:px-6 lg:px-8 border-t border-[#1E293B] bg-[#111827]">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="text-center md:text-left">
            <span className="text-foreground font-bold text-lg">NODE3</span>
            <p className="font-mono text-xs text-muted-foreground mt-1">
              desarrollo de software
            </p>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-muted-foreground hover:text-foreground text-sm transition-colors duration-200"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Copyright */}
          <p className="text-muted-foreground text-sm">
            © 2025 NODE3
          </p>
        </div>
      </div>
    </footer>
  )
}

// =============================================
// MAIN PAGE COMPONENT
// =============================================

export default function Node3LandingPage() {
  return (
    <main className="min-h-screen bg-[#0A0F1E]">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <TeamSection />
      <ProjectsSection />
      <ServicesSection />
      <ContactSection />
      <TechnologiesSection />
      <Footer />
    </main>
  )
}
